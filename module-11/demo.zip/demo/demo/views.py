from django.shortcuts import render, HttpResponse

# Created the function and called it hello since this is hello world modified with my last name.
def hello(request):
        return HttpResponse("Morrow says Hello!")